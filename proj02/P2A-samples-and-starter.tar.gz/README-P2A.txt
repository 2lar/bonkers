The one starter file in here is P2random.h, used for PR mode.

Besides the project specification, there are two additional input files that
you can use for testing: Small (100 trades) and Large (100,000 trades).
There are PR and TL mode versions of every input file; these are equivalent.

Every input file has corresponding output files named with -all (all command
line flags turned on), as well as -i (just trader info), -m (just median),
-t (just time traveler), and -v (just verbose).
